# BasicPython
How to open JUPYTER NOTEBOOK from the folder it is saved in![image](https://user-images.githubusercontent.com/58723567/145210033-19039afa-8e5c-4513-9b33-7821213bf524.png)
1. Select the address bar (where your python file is saved)
2. Type cmd
3. When cmd opens, type "jupyter notebook"



Summary
1. Int
2. Float
3. String          ''         Ordered     Immutable
4. List            []         ordered     Mutable
5. Tuple           ()         Ordered     Immutable
6. Dictionary      {}         Unordered   Mutable     
7. Sets            {}         Unordered    Mutable
8. Boolean         True, False


To check the datatype of a variable
type(varName)



Text Type : str
Numeric Type : int, float, complex
Sequence Type : list, tuple, range
Mapping Type : dict
Set Type : set, frozenset
Boolean Type : bool
Binary Type : bytes, bytesarray, memoryview
